﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace quan_ly_thu_vien.Model
{
    class ChiTietPhieuMuon
    {

    }
}
