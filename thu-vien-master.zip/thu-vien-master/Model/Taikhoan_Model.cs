﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class Taikhoan_Model
    {
        public string TenTk { get; set; }
        public string MatKhau { get; set; }
    }
}
