﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public  class Loaisach_Model
    {
        public string MaLS { get; set; }
        public string TenLS { get; set; }
    }
}
