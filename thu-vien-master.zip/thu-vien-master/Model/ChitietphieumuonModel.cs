﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class ChitietphieumuonModel
    {
        public string SoPhieuMuon { get; set; }
        public string MaSach { get; set; }
        public DateTime? HenTra { get; set; }
    }
}
