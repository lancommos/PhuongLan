﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class Phat_Model
    {
        public string MaSach { get; set; }
        public string MaThe { get; set; }
        public string LyDoPhat { get; set; }
    }
}
