﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class NXB_Model
    {
        public string MaNXB { get; set; }
        public string TenNXB { get; set; }
        public string DiaChiNXB { get; set; }
        public string Website { get; set; }
    }
}
