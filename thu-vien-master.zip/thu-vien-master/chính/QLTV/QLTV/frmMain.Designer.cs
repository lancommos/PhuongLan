﻿namespace QLTV
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.bạnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sinhViênToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sáchThưViệnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loạiSáchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nhàXuấtBảnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sáchCóTrongThưViệnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýMượnSáchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sốPhiếuMượnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nhânViênThưViệnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.menuStrip2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Location = new System.Drawing.Point(0, 24);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(697, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // menuStrip2
            // 
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bạnToolStripMenuItem,
            this.sáchThưViệnToolStripMenuItem,
            this.quảnLýMượnSáchToolStripMenuItem,
            this.nhânViênThưViệnToolStripMenuItem});
            this.menuStrip2.Location = new System.Drawing.Point(0, 0);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.Size = new System.Drawing.Size(697, 24);
            this.menuStrip2.TabIndex = 1;
            this.menuStrip2.Text = "menuStrip2";
            // 
            // bạnToolStripMenuItem
            // 
            this.bạnToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sinhViênToolStripMenuItem});
            this.bạnToolStripMenuItem.Name = "bạnToolStripMenuItem";
            this.bạnToolStripMenuItem.Size = new System.Drawing.Size(113, 20);
            this.bạnToolStripMenuItem.Text = "Bạn Đọc Thư Viện";
            // 
            // sinhViênToolStripMenuItem
            // 
            this.sinhViênToolStripMenuItem.Name = "sinhViênToolStripMenuItem";
            this.sinhViênToolStripMenuItem.Size = new System.Drawing.Size(123, 22);
            this.sinhViênToolStripMenuItem.Text = "Sinh Viên";
            this.sinhViênToolStripMenuItem.Click += new System.EventHandler(this.sinhViênToolStripMenuItem_Click);
            // 
            // sáchThưViệnToolStripMenuItem
            // 
            this.sáchThưViệnToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.loạiSáchToolStripMenuItem,
            this.nhàXuấtBảnToolStripMenuItem,
            this.sáchCóTrongThưViệnToolStripMenuItem});
            this.sáchThưViệnToolStripMenuItem.Name = "sáchThưViệnToolStripMenuItem";
            this.sáchThưViệnToolStripMenuItem.Size = new System.Drawing.Size(94, 20);
            this.sáchThưViệnToolStripMenuItem.Text = "Sách Thư Viện";
            // 
            // loạiSáchToolStripMenuItem
            // 
            this.loạiSáchToolStripMenuItem.Name = "loạiSáchToolStripMenuItem";
            this.loạiSáchToolStripMenuItem.Size = new System.Drawing.Size(193, 22);
            this.loạiSáchToolStripMenuItem.Text = "Loại Sách";
            this.loạiSáchToolStripMenuItem.Click += new System.EventHandler(this.loạiSáchToolStripMenuItem_Click);
            // 
            // nhàXuấtBảnToolStripMenuItem
            // 
            this.nhàXuấtBảnToolStripMenuItem.Name = "nhàXuấtBảnToolStripMenuItem";
            this.nhàXuấtBảnToolStripMenuItem.Size = new System.Drawing.Size(193, 22);
            this.nhàXuấtBảnToolStripMenuItem.Text = "Nhà Xuất Bản";
            this.nhàXuấtBảnToolStripMenuItem.Click += new System.EventHandler(this.nhàXuấtBảnToolStripMenuItem_Click);
            // 
            // sáchCóTrongThưViệnToolStripMenuItem
            // 
            this.sáchCóTrongThưViệnToolStripMenuItem.Name = "sáchCóTrongThưViệnToolStripMenuItem";
            this.sáchCóTrongThưViệnToolStripMenuItem.Size = new System.Drawing.Size(193, 22);
            this.sáchCóTrongThưViệnToolStripMenuItem.Text = "Sách có trong thư viện";
            this.sáchCóTrongThưViệnToolStripMenuItem.Click += new System.EventHandler(this.sáchCóTrongThưViệnToolStripMenuItem_Click);
            // 
            // quảnLýMượnSáchToolStripMenuItem
            // 
            this.quảnLýMượnSáchToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sốPhiếuMượnToolStripMenuItem});
            this.quảnLýMượnSáchToolStripMenuItem.Name = "quảnLýMượnSáchToolStripMenuItem";
            this.quảnLýMượnSáchToolStripMenuItem.Size = new System.Drawing.Size(125, 20);
            this.quảnLýMượnSáchToolStripMenuItem.Text = "Quản Lý Mượn Sách";
            // 
            // sốPhiếuMượnToolStripMenuItem
            // 
            this.sốPhiếuMượnToolStripMenuItem.Name = "sốPhiếuMượnToolStripMenuItem";
            this.sốPhiếuMượnToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.sốPhiếuMượnToolStripMenuItem.Text = "Số Phiếu Mượn ";
            this.sốPhiếuMượnToolStripMenuItem.Click += new System.EventHandler(this.sốPhiếuMượnToolStripMenuItem_Click);
            // 
            // nhânViênThưViệnToolStripMenuItem
            // 
            this.nhânViênThưViệnToolStripMenuItem.Name = "nhânViênThưViệnToolStripMenuItem";
            this.nhânViênThưViệnToolStripMenuItem.Size = new System.Drawing.Size(124, 20);
            this.nhânViênThưViệnToolStripMenuItem.Text = "Nhân Viên Thư Viện";
            this.nhânViênThưViệnToolStripMenuItem.Click += new System.EventHandler(this.nhânViênThưViệnToolStripMenuItem_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 41);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(697, 380);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(697, 421);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.menuStrip2);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frmMain";
            this.Text = "frmMain";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.MenuStrip menuStrip2;
        private System.Windows.Forms.ToolStripMenuItem bạnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sinhViênToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sáchThưViệnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loạiSáchToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nhàXuấtBảnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sáchCóTrongThưViệnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýMượnSáchToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nhânViênThưViệnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sốPhiếuMượnToolStripMenuItem;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}